//
//  main.cpp
//  SerpientesEscaleras
//
//  Created by Rosa Guadalupe Paredes Juarez on 18/05/20.
//  Copyright © 2020 Rosa Paredes. All rights reserved.
//

#include <iostream>
#include "MyGame.h"

int main(int argc, const char * argv[]) {
    MyGame g;
    g.start();
    return 0;
}
