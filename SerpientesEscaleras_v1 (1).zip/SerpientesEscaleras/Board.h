//
//  Board.h
//  SerpientesEscaleras
//
//  Created by Rosa Guadalupe Paredes Juarez on 18/05/20.
//  Copyright © 2020 Rosa Paredes. All rights reserved.
//

#ifndef Board_h
#define Board_h

#include <iostream>
#include <vector>

using namespace std;

class Board {
  private:
    vector<char> tiles;
    
  public:
    Board();
    string draw();
    char getTile(int);
};


#endif /* Board_h */
